<?php
header("Content-Type:application/json");
include('../database.php');
require '../RedisMaster.php';  
$keywords = $_GET['keywords'];
$queryExecutionTime = 0;
 $jsondata = array();

$category = $_GET['category_id'];
$publisher_id = $_GET['publisher_id'];
$log_name = '[{"publisher_id":'.'"'.$publisher_id.'"'.',"category_id":'.'"'.$category.'"'.',"keywords":'.'"'.$keywords.'"'.'}]';
$createdate = date('Y-m-d H:i:s');
$q = "SELECT name FROM dev_performo.puser JOIN dev_performo.publisher_category_mapping ON dev_performo.publisher_category_mapping.publisher_id=dev_performo.puser.publisher_id JOIN dev_performo.article_master ON dev_performo.publisher_category_mapping.id=dev_performo.article_master.pub_category_id WHERE dev_performo.publisher_category_mapping.category_id='$category'";

$resultqq= pg_query($q);
 if(pg_num_rows($resultqq)>0){
$rowque = pg_fetch_array($resultqq);
$username=$rowque['name'];

$sqlquery ="INSERT INTO dev_performo.userlog (log_name,username, created) VALUES ('$log_name','$username','$createdate')";
 $resultsql = pg_query($sqlquery); 
$jsondata = array();
if ($_GET['token_key']=="@123abcd1366" && $_GET['keywords']!='' && $category!='' && $publisher_id!='') {
	include('../database.php');
	 require '../RedisMaster.php';
	 $rediskeyatr = '{keyword}:'.$keywords.'__'.$publisher_id.'__'.$category;
	 $fromcache = false;
	$allarticlenew = [];
 if ($nredis->exists($rediskeyatr)) {
    $allarticlenew = $nredis->sRandMember($rediskeyatr);
    if ($allarticlenew) {
        $jsonArray = [];
        // Check if $allarticlenew is an array
        if (is_array($allarticlenew)) {
            foreach ($allarticlenew as $jsonString) {
                $jsonArray[] = json_decode($jsonString, true);
            }
        } else {
            // If $allarticlenew is not an array, treat it as a single JSON string
            $jsonArray[] = json_decode($allarticlenew, true);
        }
        $jsonResultnew = json_encode($jsonArray);
        echo $jsonResultnew;
    } else {
        $jsonResultnew = [];
        echo json_encode($jsonResultnew);
    }
}
	else{
	  
	   $queryStartTime = microtime(true);
	   $sqlq = "SELECT article_id FROM dev_performo.article_keyword_mapping JOIN dev_performo.article_master ON dev_performo.article_keyword_mapping.article_id=dev_performo.article_master.id JOIN dev_performo.publisher_category_mapping ON dev_performo.publisher_category_mapping.id=dev_performo.article_master.pub_category_id WHERE  dev_performo.publisher_category_mapping.category_id ='$category' AND dev_performo.publisher_category_mapping.publisher_id ='$publisher_id' AND dev_performo.article_keyword_mapping.keyword_name LIKE '%$keywords%'";
    $resultsql = pg_query($sqlq); 
     if(pg_num_rows($resultsql)>0){
    $rowsql = pg_fetch_array($resultsql);
    $article_id =$rowsql['article_id'];
    $query = "SELECT dev_performo.article_master.*,dev_performo.publisher_category_mapping.*,dev_performo.article_master.id as articleid FROM dev_performo.article_master JOIN dev_performo.publisher_category_mapping ON dev_performo.publisher_category_mapping.id =dev_performo.article_master.pub_category_id WHERE article_master.id='$article_id'"; 
    $result = pg_query($query);
     if(pg_num_rows($result)>0){
    $queryEndTime = microtime(true);
    $queryExecutionTime = $queryEndTime - $queryStartTime;
	  while ($row = pg_fetch_array($result)) {
											 $id =$rowsql['article_id'];
                        $title = $row['title'];
                        $pubdate = $row['pubdate'];
                        $link = $row['link'];
                        $categoryname = $row['category_name'];
                        $publishername = $row['publisher_name'];
                        $author = $row['author'];
                        $guid = $row['guid'];
                        $summary = $row['summary'];
                        $mediaurl = $row['mediaurl'];
                        $response_code = 0;
                        $response_desc = 'successful';
                        $jsondata = [
                            'id' => $id,
                            'title' => $title,
                            'pubdate' => $pubdate,
                            'link' => $link,
                            'category' => $categoryname,
                            'publisher' => $publishername,
                            'author' => $author,
                            'guid' => $guid,
                            'mediaurl' => $mediaurl
                        ];
      $key ='{keyword}:'.$keywords.'__'.$publisher_id.'__'.$category;
     $score = strtotime($pubdate);
     $nredis->sAdd($key, json_encode($jsondata));
     $ttlInSeconds = 3600;
     $nredis->expire($key, $ttlInSeconds);
	  response($id, $title, $pubdate, $link, $categoryname, $publishername, $author, $guid, $mediaurl, $response_code, $response_desc);

    }
    }else{
   	$emptyArray = array();
    echo json_encode($emptyArray);
    die;
   }
   }else{
   	$emptyArray = array();
    echo json_encode($emptyArray);
    die;
   }
 }

}else{
	response(NULL, NULL,NULL, NULL,NULL, NULL, NULL, 400,"Invalid Request");
	}
}else{
   	$emptyArray = array();
    echo json_encode($emptyArray);
    die;
   }
function response($id, $title, $pubdate, $link,$categoryname, $publishername, $author, $guid, $mediaurl, $response_code, $response_desc)
{
	$response['title'] = $title;
	$response['pubdate'] = $pubdate;
	$response['link'] = $link;
	$response['author'] = $author;
	$response['guid'] = $guid;
	$response['mediaurl'] = $mediaurl;
	$response['response_code'] = $response_code;
	$response['response_desc'] = $response_desc;
	$json_response = json_encode($response);
	echo $json_response;
}
//$respnseEndTime = microtime(true);
//$responseExecutionTime = $respnseEndTime - $respnseStartTime;
//echo "Query execution time: " . $queryExecutionTime. " seconds<br>";
//echo "Response execution time: " . $responseExecutionTime. " seconds<br>";
//echo 'Cache'.$fromcache;
?>
